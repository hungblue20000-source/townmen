#include "../TownsmenRebuilt/Core/VillageCore.hpp"
#include <cassert>
#include <fstream>
#include <filesystem>
#include <iostream>
using namespace townsmen;
int main(){VillageCore v;int id=-1;assert(v.canPlace(BuildingType::Lumberjack,8,8));assert(v.place(BuildingType::Lumberjack,8,8,&id));assert(v.stocks().wood==95);assert(!v.place(BuildingType::Lumberjack,8,8));v.tick(5);assert(v.buildings()[0].complete);assert(v.assignCitizen(v.citizens()[0].id,id));int wood=v.stocks().wood;v.tick(6);assert(v.stocks().wood>wood);auto path=v.findPath(0,0,3,3);assert(!path.empty());auto file=std::filesystem::temp_directory_path()/"townsmen_test.save";assert(v.save(file));VillageCore copy;assert(copy.load(file));assert(copy.buildings().size()==v.buildings().size());std::ofstream(file)<<"bad";assert(!copy.load(file));std::filesystem::remove(file);std::cout<<"core tests passed\n";}
