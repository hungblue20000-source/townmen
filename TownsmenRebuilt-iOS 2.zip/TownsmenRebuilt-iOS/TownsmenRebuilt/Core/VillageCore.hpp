#pragma once
#include <cstdint>
#include <filesystem>
#include <optional>
#include <string>
#include <unordered_map>
#include <vector>

namespace townsmen {
struct ResourceStock { int wood=120, stone=80, food=100; };
struct Cost { int wood=0, stone=0, food=0; };
enum class BuildingType { House, Warehouse, Lumberjack, Quarry, Farm };
struct Building { int id=0; BuildingType type; int x=0,y=0; bool complete=false; float progress=0; };
struct Citizen { int id=0; bool working=false; int buildingId=-1; int x=0,y=0; };
struct Tile { bool blocked=false; bool occupied=false; };
struct SaveData { int version=1; int nextBuildingId=1; int nextCitizenId=1; ResourceStock stocks; std::vector<Building> buildings; std::vector<Citizen> citizens; };

class VillageCore {
public:
    VillageCore();
    void reset();
    void tick(float seconds);
    void setPaused(bool paused); bool paused() const { return paused_; }
    void setSpeed(float speed); float speed() const { return speed_; }
    const ResourceStock& stocks() const { return data_.stocks; }
    const std::vector<Building>& buildings() const { return data_.buildings; }
    const std::vector<Citizen>& citizens() const { return data_.citizens; }
    int population() const { return static_cast<int>(data_.citizens.size()); }
    int employed() const;
    bool canPlace(BuildingType type,int x,int y) const;
    bool place(BuildingType type,int x,int y,int* idOut=nullptr);
    bool cancelConstruction(int id);
    bool demolish(int id);
    bool assignCitizen(int citizenId,int buildingId);
    std::vector<std::pair<int,int>> findPath(int sx,int sy,int ex,int ey) const;
    bool save(const std::filesystem::path& path) const;
    bool load(const std::filesystem::path& path);
    static Cost cost(BuildingType type);
    static const char* name(BuildingType type);
private:
    Tile tileAt(int x,int y) const; bool spend(Cost c); void refund(Cost c);
    SaveData data_; std::vector<Tile> map_; bool paused_=false; float speed_=1.0f; float autosave_=0;
};
}
