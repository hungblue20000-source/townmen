#include "reconstructed_production.hpp"

namespace townsmen_re {

void Stock::setAmount(float value) {
    value = std::max(0.0f, value);

    // The binary subtracts reserved amounts from capacity before clamping.
    const float freeCapacity = std::max(0.0f, capacity_ - reserved_);
    const float bounded = std::min(value, freeCapacity);

    if (std::floor(amount_) != std::floor(bounded)) {
        // The original calls a resource-change callback when the integer
        // amount changes. The callback is represented by the caller in this
        // reconstruction; the stored value remains authoritative.
    }
    amount_ = bounded;
}

int Stock::getAvailableAmountInteger() const {
    const float available = std::max(0.0f, amount_ - reserved_);
    return static_cast<int>(available); // native fcvtzs behavior
}

bool Stock::consume(float value) {
    if (value < 0.0f || amount_ + 1e-6f < value) {
        return false;
    }
    amount_ -= value;
    if (amount_ < 0.0f) amount_ = 0.0f;
    return true;
}

bool ResourceCollection::contains(const ResourceAmount& requested) const {
    if (!requested.resource) return false;
    for (const auto& entry : values_) {
        if (entry.resource == requested.resource ||
            (entry.resource && entry.resource->id == requested.resource->id)) {
            return entry.amount + 1e-6f >= requested.amount;
        }
    }
    return false;
}

bool ResourceCollection::contains(const ResourceCollection& requested) const {
    for (const auto& entry : requested.values_) {
        if (!contains(entry)) return false;
    }
    return true;
}

ProductionTask::ProductionTask(Unit* unit,
                               ResourceCollection input,
                               std::vector<ResourceAmount> output,
                               float productionTime,
                               ProductionListener* listener)
    : unit_(unit),
      input_(std::move(input)),
      output_(std::move(output)),
      productionTime_(std::max(0.0f, productionTime)),
      listener_(listener) {}

bool ProductionTask::hasRequiredInput() const {
    if (!unit_) return false;
    auto* context = unit_->context();
    if (!context) return false;

    for (const auto& required : input_.values()) {
        auto* stock = context->findStock(required.resource);
        if (!stock || stock->getAvailableAmountInteger() <
                          static_cast<int>(std::ceil(required.amount))) {
            return false;
        }
    }
    return true;
}

bool ProductionTask::consumeInput() {
    if (!unit_) return false;
    auto* context = unit_->context();
    if (!context || !hasRequiredInput()) return false;

    // The native code resolves resource slots before completing production.
    // Do a validation pass first so a partial consume cannot occur.
    std::vector<std::pair<Stock*, float>> resolved;
    for (const auto& required : input_.values()) {
        auto* stock = context->findStock(required.resource);
        if (!stock || stock->amount() + 1e-6f < required.amount) {
            return false;
        }
        resolved.emplace_back(stock, required.amount);
    }
    for (auto [stock, amount] : resolved) {
        if (!stock->consume(amount)) return false;
    }
    return true;
}

void ProductionTask::onStarted() {
    // The native symbol is a 4-byte branch to a shared task-start routine.
    started_ = true;
    state_ = ProductionState::Running;
}

void ProductionTask::update(float deltaSeconds) {
    if (state_ == ProductionState::Completed ||
        state_ == ProductionState::Cancelled) {
        return;
    }
    if (deltaSeconds < 0.0f) deltaSeconds = 0.0f;

    if (!started_) {
        if (!hasRequiredInput()) return;
        onStarted();
    }

    elapsed_ += deltaSeconds;
    if (elapsed_ < productionTime_) return;

    // The original update marks a completion flag and routes through
    // doProduction/onFinished after its task/building state checks.
    if (!productionDone_) {
        doProduction();
        productionDone_ = true;
    }
}

void ProductionTask::doProduction() {
    if (state_ != ProductionState::Running || !consumeInput()) {
        return;
    }

    for (const auto& amount : output_) {
        produceSingleResource(unit_, amount);
    }
    onFinished();
}

bool ProductionTask::produceSingleResource(Unit* unit,
                                           const ResourceAmount& output) {
    if (!unit || !output.resource || output.amount <= 0.0f) return false;
    auto* context = unit->context();
    if (!context) return false;

    auto* stock = context->findStock(output.resource);
    if (!stock) return false;

    // Assembly shows a multiplier path followed by +0.5 and integer
    // conversion, then a minimum of 1. This models that behavior.
    float amount = output.amount * context->productionMultiplier();
    amount = std::max(1.0f, std::floor(amount + 0.5f));
    const float before = stock->amount();
    stock->add(amount);
    const float produced = stock->amount() - before;

    if (listener_ && produced > 0.0f) {
        listener_->onResourceProduced(output.resource, produced);
    }
    return produced > 0.0f;
}

void ProductionTask::onFinished() {
    state_ = ProductionState::Completed;
    if (finishedCallback) finishedCallback(*this);
}

bool BasicProductionUnit::canProduceResource(Unit* unit,
                                              const Resource* resource) const {
    if (!unit || !resource) return false;
    for (const auto& output : output_) {
        if (output.resource == resource ||
            (output.resource && output.resource->id == resource->id)) {
            auto* context = unit->context();
            return context && context->findStock(resource) != nullptr;
        }
    }
    return false;
}

std::unique_ptr<ProductionTask> BasicProductionUnit::createProductionTask(
    Unit* unit, ProductionListener* listener) const {
    if (!unit || !unit->context()) return nullptr;
    if (!input_.values().empty()) {
        for (const auto& required : input_.values()) {
            auto* stock = unit->context()->findStock(required.resource);
            if (!stock || stock->getAvailableAmountInteger() <
                              static_cast<int>(std::ceil(required.amount))) {
                return nullptr;
            }
        }
    }
    return std::make_unique<ProductionTask>(
        unit, input_, output_, productionTime_, listener);
}

} // namespace townsmen_re
