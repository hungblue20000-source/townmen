#pragma once

// Reconstructed from ARM64 libmain.so symbols/disassembly.
// This is not the original source and is intentionally ABI-independent.

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <functional>
#include <memory>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

namespace townsmen_re {

struct Resource {
    std::string id;
    bool operator==(const Resource& other) const { return id == other.id; }
};

struct ResourceAmount {
    const Resource* resource{};
    float amount{};
};

class Stock {
public:
    explicit Stock(const Resource* resource = nullptr, float capacity = 0.0f)
        : resource_(resource), capacity_(std::max(0.0f, capacity)) {}

    const Resource* resource() const { return resource_; }
    float amount() const { return amount_; }
    float capacity() const { return capacity_; }
    float reserved() const { return reserved_; }

    // Matches the observed native behavior: negative values are clamped and
    // the new value is bounded by free capacity after reservations.
    void setAmount(float value);
    int getAvailableAmountInteger() const;

    void reserve(float value) { reserved_ = std::max(0.0f, reserved_ + value); }
    void add(float value) { setAmount(amount_ + value); }
    bool consume(float value);

private:
    const Resource* resource_{};
    float amount_{0.0f};
    float capacity_{0.0f};
    float reserved_{0.0f};
};

class ResourceCollection {
public:
    ResourceCollection() = default;
    explicit ResourceCollection(std::vector<ResourceAmount> values)
        : values_(std::move(values)) {}

    const std::vector<ResourceAmount>& values() const { return values_; }
    std::vector<ResourceAmount>& values() { return values_; }

    // Observed behavior: match by resource identity/id and require amount >=
    // requested amount.
    bool contains(const ResourceAmount& requested) const;
    bool contains(const ResourceCollection& requested) const;

private:
    std::vector<ResourceAmount> values_;
};

class ProductionTask;

class ProductionListener {
public:
    virtual ~ProductionListener() = default;
    virtual void onResourceProduced(const Resource* resource, float amount) = 0;
};

class ProductionContext {
public:
    virtual ~ProductionContext() = default;
    virtual Stock* findStock(const Resource* resource) = 0;
    virtual float productionMultiplier() const { return 1.0f; }
    virtual float harvestMultiplier() const { return 1.0f; }
};

class Unit {
public:
    virtual ~Unit() = default;
    virtual ProductionContext* context() const = 0;
};

enum class ProductionState {
    Waiting,
    Running,
    Completed,
    Cancelled,
};

class ProductionTask {
public:
    ProductionTask(Unit* unit,
                   ResourceCollection input,
                   std::vector<ResourceAmount> output,
                   float productionTime,
                   ProductionListener* listener = nullptr);

    void update(float deltaSeconds);
    void doProduction();
    void onStarted();
    void onFinished();

    // Reconstructed equivalent of the native helper.
    bool produceSingleResource(Unit* unit, const ResourceAmount& output);

    ProductionState state() const { return state_; }
    float elapsed() const { return elapsed_; }
    float productionTime() const { return productionTime_; }
    const ResourceCollection& input() const { return input_; }
    const std::vector<ResourceAmount>& output() const { return output_; }

    std::function<void(ProductionTask&)> finishedCallback;

private:
    bool hasRequiredInput() const;
    bool consumeInput();

    Unit* unit_{};
    ResourceCollection input_;
    std::vector<ResourceAmount> output_;
    float productionTime_{0.0f};
    float elapsed_{0.0f};
    bool started_{false};
    bool productionDone_{false};
    ProductionState state_{ProductionState::Waiting};
    ProductionListener* listener_{};
};

class BasicProductionUnit {
public:
    BasicProductionUnit(ResourceCollection input,
                        std::vector<ResourceAmount> output,
                        float productionTime)
        : input_(std::move(input)),
          output_(std::move(output)),
          productionTime_(productionTime) {}

    const ResourceCollection& getInResources() const { return input_; }
    const std::vector<ResourceAmount>& getOutResources() const { return output_; }
    float getProductionTime() const { return productionTime_; }

    bool canProduceResource(Unit* unit, const Resource* resource) const;
    std::unique_ptr<ProductionTask> createProductionTask(
        Unit* unit, ProductionListener* listener = nullptr) const;

private:
    ResourceCollection input_;
    std::vector<ResourceAmount> output_;
    float productionTime_{0.0f};
};

} // namespace townsmen_re
