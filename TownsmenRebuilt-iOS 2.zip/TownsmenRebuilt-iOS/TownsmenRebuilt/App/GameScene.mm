#import <SpriteKit/SpriteKit.h>
#include "../Core/VillageCore.hpp"
using namespace townsmen;
@interface GameScene : SKScene
@end
@implementation GameScene { VillageCore _village; SKNode *_world; SKLabelNode *_hud; CGFloat _zoom; CGPoint _last; }
-(void)didMoveToView:(SKView*)view { _zoom=1; _world=[SKNode node]; [self addChild:_world]; _hud=[SKLabelNode labelNodeWithFontNamed:@"AvenirNext-Medium"]; _hud.horizontalAlignmentMode=SKLabelHorizontalAlignmentModeLeft; _hud.verticalAlignmentMode=SKLabelVerticalAlignmentModeTop; _hud.fontSize=16; _hud.position=CGPointMake(18,self.size.height-28); [self addChild:_hud]; [self rebuild]; }
-(void)rebuild { [_world removeAllChildren]; CGFloat s=28; for(int y=0;y<20;y++)for(int x=0;x<32;x++){SKShapeNode *tile=[SKShapeNode shapeNodeWithRectOfSize:CGSizeMake(s-1,s-1)];tile.fillColor=[SKColor colorWithRed:.15 green:.28 blue:.18 alpha:1];tile.strokeColor=[SKColor colorWithWhite:.3 alpha:.25];tile.position=CGPointMake(x*s+s/2,y*s+s/2);[_world addChild:tile];} for(const auto &b:_village.buildings()){SKShapeNode *n=[SKShapeNode shapeNodeWithRectOfSize:CGSizeMake(s-5,s-5)];n.fillColor=b.complete?[SKColor colorWithRed:.75 green:.55 blue:.2 alpha:1]:[SKColor colorWithWhite:.5 alpha:.6];n.position=CGPointMake(b.x*s+s/2,b.y*s+s/2);[_world addChild:n];} _world.position=CGPointMake(30,80); _world.xScale=_world.yScale=_zoom; _hud.text=[NSString stringWithFormat:@"Gỗ %d   Đá %d   Lương thực %d   Dân %d/%d",_village.stocks().wood,_village.stocks().stone,_village.stocks().food,_village.employed(),_village.population()]; }
-(void)touchesMoved:(NSSet<UITouch*>*)touches withEvent:(UIEvent*)event {UITouch*t=touches.anyObject;CGPoint p=[t locationInNode:self];_world.position=CGPointMake(_world.position.x+p.x-_last.x,_world.position.y+p.y-_last.y);_last=p;}
-(void)touchesBegan:(NSSet<UITouch*>*)touches withEvent:(UIEvent*)event {_last=[touches.anyObject locationInNode:self];}
-(void)touchesEnded:(NSSet<UITouch*>*)touches withEvent:(UIEvent*)event {CGPoint p=[touches.anyObject locationInNode:self];if(fabs(p.x-_last.x)<8&&fabs(p.y-_last.y)<8){CGPoint q=[self convertPoint:p toNode:_world];int x=(int)(q.x/28),y=(int)(q.y/28);if(_village.place(BuildingType::Farm,x,y)) [self rebuild];}}
-(void)didSimulatePhysics { _village.tick(1.0/60.0); [self rebuild]; }
@end
