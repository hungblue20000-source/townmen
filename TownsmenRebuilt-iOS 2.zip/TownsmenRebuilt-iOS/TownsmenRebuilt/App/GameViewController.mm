#import "GameViewController.h"
#import <SpriteKit/SpriteKit.h>
@interface GameScene : SKScene @end
@implementation GameViewController
-(void)loadView { self.view=[SKView new]; }
-(void)viewDidLoad { [super viewDidLoad]; SKView *view=(SKView*)self.view; GameScene *scene=[GameScene sceneWithSize:view.bounds.size]; scene.scaleMode=SKSceneScaleModeResizeFill; [view presentScene:scene]; }
-(BOOL)prefersHomeIndicatorAutoHidden { return YES; }
-(UIInterfaceOrientationMask)supportedInterfaceOrientations { return UIInterfaceOrientationMaskLandscape; }
@end
