#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
if ! command -v xcodebuild >/dev/null 2>&1; then
  echo "xcodebuild không có. Hãy chạy script này trên macOS có Xcode." >&2
  exit 2
fi
MODE="${1:-simulator}"
if [[ "$MODE" == "simulator" ]]; then
  xcodebuild -project "$ROOT/TownsmenRebuilt.xcodeproj" -scheme TownsmenRebuilt -sdk iphonesimulator -configuration Debug -derivedDataPath "$ROOT/build" build CODE_SIGNING_ALLOWED=NO
elif [[ "$MODE" == "device" ]]; then
  xcodebuild -project "$ROOT/TownsmenRebuilt.xcodeproj" -scheme TownsmenRebuilt -sdk iphoneos -configuration Release -derivedDataPath "$ROOT/build" build
else
  echo "Usage: $0 [simulator|device]" >&2; exit 1
fi
