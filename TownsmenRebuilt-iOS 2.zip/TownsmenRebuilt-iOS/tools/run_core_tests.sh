#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
g++ -std=c++17 -Wall -Wextra -pedantic "$ROOT/TownsmenRebuilt/Core/VillageCore.cpp" "$ROOT/Tests/core_tests.cpp" -o /tmp/townsmen_core_tests
/tmp/townsmen_core_tests
