# Townsmen Rebuilt iOS

Đây là bản tái dựng độc lập từ tài nguyên APK/decompile và module C++ reconstructed. Đây **không phải source gốc** của Townsmen và không link/chạy `libmain.so` Android, Java, DEX, JNI hay thư viện `.so`.

## Đã triển khai

- Lõi gameplay C++17 độc lập nền tảng trong `TownsmenRebuilt/Core`.
- Tài nguyên gỗ/đá/lương thực và sản xuất theo thời gian.
- Nhà ở, kho, trại gỗ, mỏ đá và nông trại.
- Đặt/hủy công trình với giao dịch chi phí nguyên tử.
- Dân cư, phân công lao động và giới hạn sản xuất.
- Bản đồ ô, kiểm tra vị trí và BFS tránh ô chiếm/chặn.
- Save/load phiên bản 1, ghi file tạm rồi đổi tên, từ chối file hỏng.
- Giao diện SpriteKit Objective-C++ màn hình ngang, kéo bản đồ và thao tác chạm đặt nông trại.
- Không có quảng cáo, mua hàng, tài khoản hay máy chủ.

## Kiểm tra lõi C++

Trên Linux/macOS có g++:

```bash
./tools/run_core_tests.sh
```

## Build iOS

Môi trường tạo ZIP không có macOS/Xcode (`xcodebuild` không tồn tại), nên iOS Simulator và thiết bị **chưa được build/kiểm chứng tại đây**.

Trên máy Mac có Xcode:

```bash
./tools/build_ios.sh simulator
./tools/build_ios.sh device
```

Build thiết bị cần cấu hình Signing Team/Certificate trong Xcode. Không có IPA giả trong gói này.

Mở project:

```text
TownsmenRebuilt.xcodeproj
```

## Tài nguyên từ ZIP

Các ZIP gốc có nhiều atlas/animation/PNG Android nhưng phần lớn là tài nguyên Cocos2d-x cần metadata runtime riêng. Bản iOS phase này dùng hình vẽ SpriteKit procedural để tránh dùng sai atlas/toạ độ hoặc phụ thuộc Android. Các asset gốc vẫn được giữ trong gói phân tích trước đó để xử lý riêng ở phase tiếp theo.

## Giới hạn

Đây là vertical slice chơi được của luật chơi tái dựng, chưa phải bản clone đầy đủ. Chưa có toàn bộ UI menu/tiếp tục trực quan, hệ thống dân di chuyển theo thời gian thực đầy đủ, tất cả building/quest/disaster của binary và chưa có kiểm chứng trên iPhone. Các giới hạn này được nêu rõ thay vì coi project là hoàn tất giả.
